<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produto extends CI_Controller {
	private $codigo;
    private $descricao;
    private $cod_unid_medida;
    private $maxEstoque;
    private $minEstoque;
    private $estatus;
    private $tipoUsuario;
    private $usuarioLogin;

    // Getters
    public function getCodigo()
	{ 
		return $this->codigo;
	}

	public function getDescricao()
	{
		return $this->descricao;
	}

    public function getUnidMedida()
	{
		return $this->cod_unid_medida;
	}

    public function getMaxEstoque()
	{ 
		return $this->maxEstoque;
	}

    public function getMinEstoque()
	{ 
		return $this->minEstoque;
	}

    public function getEstatus()
	{ 
		return $this->estatus; 
	}

    public function getTipoUsuario()
	{
		return $this->tipoUsuario;
	}

    public function getUsuarioLogin()
	{
		return $this->usuarioLogin;
	}

    // Setters
    public function setCodigo($codigoFront)
	{ 
		$this->codigo = $codigoFront;
	}

	public function setDescricao($descricaoFront) 
	{ 
		$this->descricao = $descricaoFront; 
	}

    public function setUnidMedida($cod_unid_medidaFront) 
	{ 
		$this->cod_unid_medida = $cod_unid_medidaFront; 
	}

    public function setMaxEstoque($maxEstoqueFront) 
	{ 
		$this->maxEstoque = $maxEstoqueFront; 
	}

    public function setMinEstoque($minEstoqueFront) 
	{ 
		$this->minEstoque = $minEstoqueFront; 
	}

    public function setEstatus($estatusFront) 
	{ 
		$this->estatus = $estatusFront; 
	}

    public function setUsuarioLogin($usuarioLoginFront) 
	{ 
		$this->usuarioLogin = $usuarioLoginFront; 
	}

    public function inserir() {
        try {
            $json = file_get_contents('php://input');
            $resultado = json_decode($json);

            $lista = array(
                "descricao" => '0',
                "cod_unid_medida" => '0',
                "minEstoque" => '0',
                "maxEstoque" => '0',
                "usuarioLogin" => '0',
            );

            if (verificarParam($resultado, $lista) == 1) {
                $this->setDescricao($resultado->descricao);
                $this->setUnidMedida($resultado->cod_unid_medida);
                $this->setMinEstoque($resultado->minEstoque);
                $this->setMaxEstoque($resultado->maxEstoque);
                $this->setUsuarioLogin($resultado->usuarioLogin);

				$this->load->model('M_produto');
                if (!$this->M_produto->verificarUsuarioExistente($this->getUsuarioLogin())) {
                    $retorno = array(
                        'codigo' => 1,
                        'msg' => 'Usuário não cadastrado na base de dados.'
                    );
                } elseif (trim($this->getDescricao()) == '') {
                    $retorno = array('codigo' => 2, 'msg' => 'Descrição não informada');
                } elseif (trim($this->getMinEstoque()) == '') {
                    $retorno = array('codigo' => 3, 'msg' => 'Estoque mínimo não definido');
                } elseif (trim($this->getMaxEstoque()) == '') {
                    $retorno = array('codigo' => 4, 'msg' => 'Estoque máximo não definido');
                } elseif (trim($this->getUnidMedida()) == '') {
                    $retorno = array('codigo' => 5, 'msg' => 'Unidade de medida não informada');
                } elseif (trim($this->getUsuarioLogin()) == '') {
                    $retorno = array('codigo' => 6, 'msg' => 'Usuário logado no sistema não informado');
                } elseif ($this->M_produto->verificarDescricaoExistente($this->getDescricao())) { // Nova verificação
                    $retorno = array('codigo' => 6, 'msg' => 'A descrição já se encontra cadastrada na base de dados.');
                } else {
                    $this->load->model('M_produto');
                    $retorno = $this->M_produto->inserir(
                        $this->getDescricao(),
                        $this->getUnidMedida(),
                        $this->getMinEstoque(),
                        $this->getMaxEstoque(),
                        $this->getUsuarioLogin()
                    );
                }
            } else {
                $retorno = array('codigo' => 99, 'msg' => 'Campos vindos do Frontend não representam o método de login. Verifique.');
            }
        } catch (Exception $e) {
            $retorno = array('codigo' => 0, 'msg' => 'ATENÇÃO: O seguinte erro ocorreu -> ' . $e->getMessage());
        }
        echo json_encode($retorno);
    }

	public function consultar()
	{
		//Nome, descrição, Minimo e máximo estoque
		//recebidos via json e colocados em variáveis
		//retornos possiveis:
		//2 - o nome do produto não pode ultrapassar 50 caracteres (front)		
		try {
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);
			$lista = array(
				"codigo" => '0',
				"descricao" => '0',
				"minEstoque" => '0',
				"maxEstoque" => '0'
			);

			//Setters
			if (verificarParam($resultado, $lista) == 1) {
				$this->setcodigo($resultado->codigo);
				$this->setDescricao($resultado->descricao);
				$this->setminEstoque($resultado->minEstoque);
				$this->setmaxEstoque($resultado->maxEstoque);

				if (strlen($this->getDescricao()) > 50) {
					$retorno = array(
						'Codigo' => 2,
						'msg' => 'O Nome do produto não pode ultrapassar 50 caracteres.'
					);
				} else {
					$this->load->model('M_produto');
					$retorno = $this->M_produto->consultar($this->getCodigo(), $this->getDescricao(), $this->getminEstoque(), $this->getmaxEstoque());
				}
			} else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam o método de login. Verifique.'
				);
			}
		} catch (Exception $e) {
			$retorno = array(
				'codigo' => 99,
				'msg' => 'Atenção: o seguinte erro aconteceu ->',
				$e->getMessage()
			);
		}
		echo json_encode($retorno);
	}

    public function consultar_desativado()
	{
		//Nome, descrição, Minimo e máximo estoque
		//recebidos via json e colocados em variáveis
		//retornos possiveis:
		//2 - o nome do produto não pode ultrapassar 50 caracteres (front)		
		try {
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);
			$lista = array(
				"codigo" => '0',
				"descricao" => '0',
			);

			//Setters
			if (verificarParam($resultado, $lista) == 1) {
				$this->setcodigo($resultado->codigo);
				$this->setDescricao($resultado->descricao);

				if (strlen($this->getDescricao()) > 50) {
					$retorno = array(
						'Codigo' => 2,
						'msg' => 'O Nome do produto não pode ultrapassar 50 caracteres.'
					);
				} else {
					$this->load->model('M_produto');
					$retorno = $this->M_produto->consultar_desativado($this->getCodigo(), $this->getDescricao());
				}
			} else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam o método de login. Verifique.'
				);
			}
		} catch (Exception $e) {
			$retorno = array(
				'codigo' => 99,
				'msg' => 'Atenção: o seguinte erro aconteceu ->',
				$e->getMessage()
			);
		}
		echo json_encode($retorno);
	}

	public function alterar()
	{
		//descricao,min,max,estatus
		//recebidos via json e colocados em variáveis
		//retornos possiveis:

		try {
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);

			$lista = array(
                "codigo" => '0',
				"descricao" => '0',
                "unid_medida" => '0',
				"minEstoque" => '0',
				"maxEstoque" => '0',
				"estatus" => '0',
				"usuarioLogin" => '0'
			);

			if (verificarParam($resultado, $lista) == 1) {
				//setters
                $this->setcodigo($resultado->codigo);
				$this->setDescricao($resultado->descricao);
                $this->setUnidMedida($resultado->unid_medida);
				$this->setminEstoque($resultado->minEstoque);
				$this->setmaxEstoque($resultado->maxEstoque);
				$this->setestatus($resultado->estatus);
				$this->setUsuarioLogin($resultado->usuarioLogin);

				//validação de login do usuário
				if ($this->getEstatus() != 'A' && $this->getEstatus() != 'a') {
					$retorno = array(
						'codigo' => 8,
						'msg' => 'Estatus deve ser A ou a para alteração'
					);
				} else {

					if (trim($this->getUsuarioLogin() == '')) {
						$retorno = array(
							'codigo' => 2,
							'msg' => 'Usuário não informado'
						);
					} elseif (trim($this->getDescricao()) == '' && trim($this->getminEstoque()) == '' && trim($this->getmaxEstoque()) == '' && $this->getestatus() == '') {
						$retorno = array(
							'codigo' => '6',
							'msg' => 'Pelo menos 1 parâmetro deve ser passado para a atualização'
						);
					} elseif (trim($this->getUsuarioLogin() == '')) {
						$retorno = array(
							'codigo' => 7,
							'msg' => 'Usuário logado no sistema não informado'
						);
					} else {
						//Instancia da model
						$this->load->model('M_produto');
						//$retorno volta com as alterações dos dados
						$retorno = $this->M_produto->alterar($this->getCodigo(), $this->getDescricao(), $this->getUnidMedida(), $this->getminEstoque(), $this->getmaxEstoque(), $this->getestatus(), $this->getUsuarioLogin());
					}
				}
			} else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam 
					          o método de login. Verifique.'
				);
			}
		} catch (Exception $e) {
			$retorno = array(
				'codigo' => 0,
				'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
				$e->getMessage()
			);
		}
		//Retorno no formato JSON
		echo json_encode($retorno);
	}
	public function desativar()
	{
		//Usuário recebido via JSON e colocado em variável
		//Retornos possíveis:

		try {
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);
			//array com os dados que deverão vir do front
			$lista = array(
				"codigo" => '0',
				"usuarioLogin" => '0'
			);
			if (verificarParam($resultado, $lista) == 1) {
				//Fazendo os setters
				$this->setCodigo($resultado->codigo);
				$this->setUsuarioLogin($resultado->usuarioLogin);


				if (trim($this->getCodigo()) == '' || trim($this->getCodigo()) == 0) {
					$retorno = array(
						'codigo' => 2,
						'msg' => 'Código não informado.'
					);
				} elseif (trim($this->getUsuarioLogin()) == '') {
					$retorno = array(
						'codigo' => 5,
						'msg' => 'Usuario não informado.'
					);
				} else {
					$this->load->model('M_produto');

					$retorno = $this->M_produto->desativar(
						$this->getCodigo(),
						$this->getUsuarioLogin()
					);
				}
			} else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam o método de login. Verifique.'
				);
			}
		} catch (Exception $e) {
			$retorno = array(
				'codigo' => 0,
				'msg' => 'ATENCAO: O seguinte erro aconteceu -> ',
				$e->getMessage()
			);
		}

		echo json_encode($retorno);
	}
}