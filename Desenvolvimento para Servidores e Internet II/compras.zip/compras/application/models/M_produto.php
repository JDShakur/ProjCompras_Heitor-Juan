<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_produto extends CI_Model {
    public function inserir($descricao, $cod_unid_medida, $maxEstoque, $minEstoque, $usuarioLogin) {
        try {
            $sql = "INSERT INTO produtos (descricao, unid_medida, estoq_maximo, estoq_minimo, usucria) 
                    VALUES ('$descricao', '$cod_unid_medida', '$maxEstoque', '$minEstoque', '$usuarioLogin')";
            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $this->load->model('M_log');
                $retornoLog = $this->M_log->inserirLog($usuarioLogin, $sql);

                if ($retornoLog['codigo'] == 1) {
                    $dados = array('codigo' => 1, 'msg' => 'Produto cadastrado corretamente');
                } else {
                    $dados = array('codigo' => 8, 'msg' => 'Problema no salvamento do log, produto cadastrado corretamente.');
                }
            } else {
                $dados = array('codigo' => 6, 'msg' => 'Houve algum problema na inserção na tabela de produtos');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 0, 'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }
        return $dados;
    }

    public function consultar($codigo, $descricao, $estoq_minimo, $estoq_maximo){
        try{
            $sql = "SELECT * FROM produtos WHERE estatus = 'A'";

            if ($codigo != '' && $codigo != '0') {
                $sql .= "AND cod_produto = '$codigo' ";
            }

            if ($descricao != '') {
                $sql .= "AND descricao LIKE '%$descricao%' ";
            }

            if ($estoq_minimo != '') {
                $sql .= "AND estoq_minimo >= $estoq_minimo ";
            }

            if ($estoq_maximo != '') {
                $sql .= "AND estoq_maximo <= $estoq_maximo ";
            }

            $retorno = $this->db->query($sql);

            if ($retorno->num_rows() > 0) {
                $dados = array('codigo' => 1,
                               'msg' => 'Consulta realizada com sucesso.',
                               'dados' => $retorno->result());
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Dados não encontrados.');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }

        return $dados;
    }

    public function consultar_desativado($codigo, $descricao){
        try{
            $sql = "SELECT * FROM produtos WHERE estatus = 'D'";

            if ($codigo != '' && $codigo != '0') {
                $sql .= "AND cod_produto = '$codigo' ";
            }

            if ($descricao != '') {
                $sql .= "AND descricao LIKE '%$descricao%' ";
            }

            $retorno = $this->db->query($sql);

            if ($retorno->num_rows() > 0) {
                $dados = array('codigo' => 1,
                               'msg' => 'Consulta realizada com sucesso.',
                               'dados' => $retorno->result());
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Dados não encontrados.');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }

        return $dados;
    }

    public function alterar($codigo, $descricao, $cod_unid_medida, $estoq_minimo, $estoq_maximo, $estatus, $usuarioLogin){
        try{
            $sql = "UPDATE produtos SET ";
            $campos = [];

            if ($codigo != '') {
                $campos[] = "cod_produto = '$codigo'";
            }
            if ($descricao != '') {
                $campos[] = "descricao = '$descricao'";
            }
            if ($cod_unid_medida != '') {
                $campos[] = "unid_medida = '$cod_unid_medida'";
            }
            if ($estoq_minimo != '') {
                $campos[] = "estoq_minimo = $estoq_minimo";
            }
            if ($estoq_maximo != '') {
                $campos[] = "estoq_maximo = $estoq_maximo";
            }
            if ($estatus != '' && $estatus != 'D' && $estatus == 'A' || $estatus == 'a') {
                $campos[] = "estatus = '$estatus'";
            }

            $sql .= implode(', ', $campos) . " WHERE cod_produto = $codigo";

            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);

                if ($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Produto atualizado corretamente.');
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, o Produto foi atualizado corretamente.');
                }
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Nenhuma alteração realizada.');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }

        return $dados;
    }

    public function desativar($codigo, $usuarioLogin){
        try{
            $sql = "UPDATE produtos SET estatus = 'D' WHERE cod_produto = $codigo";

            $this->db->query($sql);

            if ($this->db->affected_rows() > 0) {
                $this->load->model('M_log');

                $retorno_log = $this->M_log->inserirLog($usuarioLogin, $sql);

                if ($retorno_log['codigo'] == 1) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Produto desativado corretamente.');
                } else {
                    $dados = array('codigo' => 7,
                                   'msg' => 'Houve algum problema no salvamento do log, porém, o Produto foi desativado corretamente.');
                }
            } else {
                $dados = array('codigo' => 6,
                               'msg' => 'Houve algum problema na desativação do produto.');
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage());
        }

        return $dados;
    }

    public function verificarUsuarioExistente($usuarioLogin) {
        $this->db->where('usuario', $usuarioLogin);
        $query = $this->db->get('usuarios');

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function verificarDescricaoExistente($descricao) {
        $this->db->where('descricao', $descricao);
        $query = $this->db->get('produtos'); 
       
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
?>
